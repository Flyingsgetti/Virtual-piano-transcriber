"""
Simplified piano note transcription using librosa.
This is a lightweight alternative that uses basic pitch detection.
"""

import os
import tempfile
from typing import List, Tuple
import numpy as np

try:
    from moviepy import VideoFileClip
except ImportError:
    try:
        from moviepy.editor import VideoFileClip
    except ImportError:
        print("moviepy not installed. Install with: pip install moviepy")
        raise

try:
    import librosa
except ImportError:
    print("librosa not installed. Install with: pip install librosa")
    raise


class SimplePianoTranscriber:
    """Transcribes piano notes using librosa's pitch detection."""

    def __init__(self):
        """Initialize the transcriber."""
        self.sr = 44100  # Sample rate

    def extract_audio(self, video_path: str) -> str:
        """
        Extract audio from video file.

        Args:
            video_path: Path to the video file

        Returns:
            Path to the extracted audio file (WAV format)
        """
        print(f"Extracting audio from {video_path}...")

        # Create a temporary file for the audio
        temp_audio = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
        temp_audio_path = temp_audio.name
        temp_audio.close()

        # Extract audio using moviepy
        video = VideoFileClip(video_path)
        video.audio.write_audiofile(temp_audio_path, logger=None)
        video.close()

        print(f"Audio extracted to {temp_audio_path}")
        return temp_audio_path

    def hz_to_midi(self, frequency: float) -> int:
        """
        Convert frequency in Hz to MIDI note number.

        Args:
            frequency: Frequency in Hz

        Returns:
            MIDI note number
        """
        if frequency <= 0:
            return 0
        return int(round(12 * np.log2(frequency / 440.0) + 69))

    def transcribe(self, audio_path: str) -> List[Tuple[float, float, int]]:
        """
        Transcribe piano notes from audio file using pYin.

        Args:
            audio_path: Path to the audio file

        Returns:
            List of tuples (onset_time, offset_time, midi_note)
        """
        print(f"Transcribing piano notes from {audio_path}...")

        # Load audio
        y, sr = librosa.load(audio_path, sr=self.sr)

        # Use pYin for pitch tracking
        # pYin returns: pitches (Hz), voiced_flag, voiced_probabilities
        pitches, voiced_flags, voiced_probs = librosa.pyin(
            y,
            fmin=librosa.note_to_hz('C2'),
            fmax=librosa.note_to_hz('C7'),
            sr=sr,
            frame_length=2048,
            hop_length=512
        )

        # Detect onsets
        onset_frames = librosa.onset.onset_detect(
            y=y,
            sr=sr,
            hop_length=512,
            backtrack=True
        )

        # Convert frame indices to time
        times = librosa.frames_to_time(
            np.arange(len(pitches)),
            sr=sr,
            hop_length=512
        )

        onset_times = librosa.frames_to_time(onset_frames, sr=sr, hop_length=512)

        # Build note events
        notes = []
        current_notes = {}  # Map MIDI note to onset time

        for i, (pitch, is_voiced) in enumerate(zip(pitches, voiced_flags)):
            if is_voiced and not np.isnan(pitch):
                midi_note = self.hz_to_midi(pitch)

                # Check if this is a new note (onset)
                current_time = times[i]

                # If this MIDI note isn't currently active, start it
                if midi_note not in current_notes:
                    current_notes[midi_note] = current_time

            else:
                # Silence or unvoiced - end active notes
                current_time = times[i] if i < len(times) else times[-1]
                notes_to_remove = []

                for midi_note, onset_time in current_notes.items():
                    # End the note
                    offset_time = current_time
                    notes.append((onset_time, offset_time, midi_note))
                    notes_to_remove.append(midi_note)

                for midi_note in notes_to_remove:
                    del current_notes[midi_note]

        # End any remaining notes
        for midi_note, onset_time in current_notes.items():
            notes.append((onset_time, times[-1], midi_note))

        # Filter out very short notes (likely noise)
        min_duration = 0.05  # 50ms minimum
        notes = [n for n in notes if n[1] - n[0] >= min_duration]

        print(f"Detected {len(notes)} notes")
        return notes

    def process_video(self, video_path: str) -> List[Tuple[float, float, int]]:
        """
        Process a video file: extract audio and transcribe notes.

        Args:
            video_path: Path to the video file

        Returns:
            List of tuples (onset_time, offset_time, midi_note)
        """
        # Extract audio
        audio_path = self.extract_audio(video_path)

        try:
            # Transcribe notes
            notes = self.transcribe(audio_path)
            return notes
        finally:
            # Clean up temporary audio file
            if os.path.exists(audio_path):
                os.remove(audio_path)
                print(f"Cleaned up temporary audio file")
