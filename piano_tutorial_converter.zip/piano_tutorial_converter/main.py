"""
Main CLI interface for piano tutorial to virtual piano converter.
"""

import argparse
import sys
from transcriber import PianoTranscriber
from simple_transcriber import SimplePianoTranscriber
from formatter import VirtualPianoFormatter


def main():
    parser = argparse.ArgumentParser(
        description='Convert piano tutorial videos to virtual piano key sequences'
    )
    parser.add_argument(
        'video_path',
        help='Path to the MP4 video file'
    )
    parser.add_argument(
        '--output', '-o',
        help='Output file path (default: output.txt)',
        default='output.txt'
    )
    parser.add_argument(
        '--time-resolution', '-t',
        type=float,
        help='Time resolution in seconds for grouping notes (default: 0.1)',
        default=0.1
    )
    parser.add_argument(
        '--with-timing',
        action='store_true',
        help='Include timing information in output'
    )
    parser.add_argument(
        '--groups-per-row',
        type=int,
        help='Number of note groups per row in output (default: 12)',
        default=12
    )
    parser.add_argument(
        '--simple',
        action='store_true',
        help='Use simple pitch detection (faster but less accurate) instead of ML model'
    )

    args = parser.parse_args()

    # Check if video file exists
    try:
        with open(args.video_path, 'rb') as f:
            pass
    except FileNotFoundError:
        print(f"Error: Video file '{args.video_path}' not found.")
        sys.exit(1)
    except Exception as e:
        print(f"Error: Could not read video file: {e}")
        sys.exit(1)

    print(f"Processing video: {args.video_path}")
    print("-" * 50)

    try:
        # Initialize transcriber
        if args.simple:
            print("Using simple pitch detection (faster but less accurate)")
            transcriber = SimplePianoTranscriber()
        else:
            print("Using ML-based piano transcription (more accurate)")
            transcriber = PianoTranscriber()

        # Process video
        notes = transcriber.process_video(args.video_path)

        if not notes:
            print("No notes detected. The video may not contain piano audio.")
            sys.exit(0)

        # Initialize formatter
        formatter = VirtualPianoFormatter(time_resolution=args.time_resolution)
        formatter.groups_per_row = args.groups_per_row

        # Format output
        if args.with_timing:
            output = formatter.format_with_timing(notes)
        else:
            output = formatter.format_sequence(notes)

        # Print to stdout
        print("\n" + "=" * 50)
        print("VIRTUAL PIANO KEY SEQUENCE:")
        print("=" * 50)
        print(output)
        print("=" * 50)

        # Save to file
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)

        print(f"\nOutput saved to: {args.output}")
        print(f"Total notes detected: {len(notes)}")

    except Exception as e:
        print(f"Error during processing: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
