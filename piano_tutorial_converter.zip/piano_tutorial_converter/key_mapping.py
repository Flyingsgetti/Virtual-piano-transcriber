"""
Virtual piano key mapping system.
Maps MIDI note numbers to keyboard key labels.
"""

# Common virtual piano keyboard layout
# This mapping follows the standard layout for online virtual pianos
# MIDI note 60 = Middle C (C4)

KEY_MAPPING = {
    # Bottom row (z-m) - Lower octave (around C3-B3)
    48: 'z',  # C3
    49: 's',  # C#3
    50: 'x',  # D3
    51: 'd',  # D#3
    52: 'c',  # E3
    53: 'v',  # F3
    54: 'g',  # F#3
    55: 'b',  # G3
    56: 'h',  # G#3
    57: 'n',  # A3
    58: 'j',  # A#3
    59: 'm',  # B3

    # Lower middle row (a-l) - Middle octave (C4-B4)
    60: 'q',  # C4 (Middle C)
    61: '2',  # C#4
    62: 'w',  # D4
    63: '3',  # D#4
    64: 'e',  # E4
    65: 'r',  # F4
    66: '5',  # F#4
    67: 't',  # G4
    68: '6',  # G#4
    69: 'y',  # A4
    70: '7',  # A#4
    71: 'u',  # B4

    # Upper middle row (a-l) - Another octave mapping (C5-B5)
    72: 'i',  # C5
    73: '9',  # C#5
    74: 'o',  # D5
    75: '0',  # D#5
    76: 'p',  # E5
    77: '[',  # F5
    78: '=',  # F#5
    79: ']',  # G5

    # Alternative mapping based on the example output pattern
    # Adjusting to match the keys seen in the example
}

# Extended mapping to cover more octaves
# Pattern: White keys (natural) = unshifted, Black keys (sharp) = shifted
# Left side of piano (low notes) = number keys 1-7
# Right side of piano (high notes) = letter keys
EXTENDED_KEY_MAPPING = {
    # Octave 2 (C2-B2) - LOWEST octave - using number row 1-7
    # Natural (white): 1, 2, 3, 4, 5, 6, 7
    # Sharp (black): !, @, #, $, %, ^
    36: '1',   # C2 (white, lowest note)
    37: '!',   # C#2 (black, shift+1)
    38: '2',   # D2 (white)
    39: '@',   # D#2 (black, shift+2)
    40: '3',   # E2 (white)
    41: '4',   # F2 (white)
    42: '$',   # F#2 (black, shift+4)
    43: '5',   # G2 (white)
    44: '%',   # G#2 (black, shift+5)
    45: '6',   # A2 (white)
    46: '^',   # A#2 (black, shift+6)
    47: '7',   # B2 (white)

    # Octave 3 (C3-B3) - using z-m row
    48: 'z',   # C3 (white)
    49: 'Z',   # C#3 (black, shift+z)
    50: 'x',   # D3 (white)
    51: 'X',   # D#3 (black, shift+x)
    52: 'c',   # E3 (white)
    53: 'v',   # F3 (white)
    54: 'V',   # F#3 (black, shift+v)
    55: 'b',   # G3 (white)
    56: 'B',   # G#3 (black, shift+b)
    57: 'n',   # A3 (white)
    58: 'N',   # A#3 (black, shift+n)
    59: 'm',   # B3 (white)

    # Octave 4 (C4-B4) - Middle C - using a-l row
    60: 'a',   # C4 (white, Middle C)
    61: 'A',   # C#4 (black, shift+a)
    62: 's',   # D4 (white)
    63: 'S',   # D#4 (black, shift+s)
    64: 'd',   # E4 (white)
    65: 'f',   # F4 (white)
    66: 'F',   # F#4 (black, shift+f)
    67: 'g',   # G4 (white)
    68: 'G',   # G#4 (black, shift+g)
    69: 'h',   # A4 (white)
    70: 'H',   # A#4 (black, shift+h)
    71: 'j',   # B4 (white)

    # Octave 5 (C5-B5) - using q-p row
    72: 'q',   # C5 (white)
    73: 'Q',   # C#5 (black, shift+q)
    74: 'w',   # D5 (white)
    75: 'W',   # D#5 (black, shift+w)
    76: 'e',   # E5 (white)
    77: 'r',   # F5 (white)
    78: 'R',   # F#5 (black, shift+r)
    79: 't',   # G5 (white)
    80: 'T',   # G#5 (black, shift+t)
    81: 'y',   # A5 (white)
    82: 'Y',   # A#5 (black, shift+y)
    83: 'u',   # B5 (white)

    # Octave 6 (C6-B6) - HIGHEST octave - using i-p row
    84: 'i',   # C6 (white)
    85: 'I',   # C#6 (black, shift+i)
    86: 'o',   # D6 (white)
    87: 'O',   # D#6 (black, shift+o)
    88: 'p',   # E6 (white)
    89: '[',   # F6 (white)
    90: '{',   # F#6 (black, shift+[)
    91: ']',   # G6 (white)
}

# Fallback mapping based on note name and octave
def midi_to_key(midi_note: int) -> str:
    """
    Convert a MIDI note number to a virtual piano key label.
    Returns the key character or '?' if not found.
    """
    # Try extended mapping first
    if midi_note in EXTENDED_KEY_MAPPING:
        return EXTENDED_KEY_MAPPING[midi_note]

    # Calculate note name and octave
    note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    note_name = note_names[midi_note % 12]
    octave = midi_note // 12 - 1

    # For unmapped notes, try to find a reasonable mapping
    # This maps notes cyclically to available keys
    all_keys = list(EXTENDED_KEY_MAPPING.values())

    # Find the closest mapped note
    closest_midi = min(EXTENDED_KEY_MAPPING.keys(), key=lambda x: abs(x - midi_note))
    offset = midi_note - closest_midi

    # Calculate which key to use based on offset
    # Map notes within reasonable range to available keys
    if -12 <= offset <= 12:
        # Within one octave, try to find a pattern
        base_key = EXTENDED_KEY_MAPPING[closest_midi]
        # Find index of base_key in all_keys
        try:
            base_index = all_keys.index(base_key)
            new_index = (base_index + offset) % len(all_keys)
            return all_keys[new_index]
        except ValueError:
            pass

    # Fallback: use note name as a placeholder
    return note_name

def note_name_to_midi(note_name: str) -> int:
    """
    Convert a note name (e.g., 'C4', 'A#5') to MIDI note number.
    """
    note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    note = note_name[:-1]
    octave = int(note_name[-1])

    note_index = note_names.index(note)
    return note_index + (octave + 1) * 12
