"""
Example usage of the piano tutorial converter.
This script demonstrates how to use the converter programmatically.
"""

from transcriber import PianoTranscriber
from simple_transcriber import SimplePianoTranscriber
from formatter import VirtualPianoFormatter


def convert_video_to_keys(video_path: str, use_simple: bool = False):
    """
    Convert a piano tutorial video to virtual piano keys.

    Args:
        video_path: Path to the MP4 video file
        use_simple: If True, use simple pitch detection (faster but less accurate)
    """
    # Initialize transcriber
    if use_simple:
        print("Using simple pitch detection...")
        transcriber = SimplePianoTranscriber()
    else:
        print("Using ML-based transcription...")
        transcriber = PianoTranscriber()

    # Process video
    notes = transcriber.process_video(video_path)

    if not notes:
        print("No notes detected!")
        return

    # Initialize formatter
    formatter = VirtualPianoFormatter(time_resolution=0.1)

    # Format output
    output = formatter.format_sequence(notes)

    print("\n" + "=" * 50)
    print("VIRTUAL PIANO KEY SEQUENCE:")
    print("=" * 50)
    print(output)
    print("=" * 50)

    # Also show with timing
    print("\nWith timing:")
    print(formatter.format_with_timing(notes))

    return output


if __name__ == '__main__':
    import sys

    if len(sys.argv) < 2:
        print("Usage: python example_usage.py <video_path> [--simple]")
        sys.exit(1)

    video_path = sys.argv[1]
    use_simple = '--simple' in sys.argv

    convert_video_to_keys(video_path, use_simple)
