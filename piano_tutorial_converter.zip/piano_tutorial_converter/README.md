# Piano Tutorial to Virtual Piano Converter

Converts MP4 piano tutorial videos into virtual piano key sequences compatible with online virtual pianos.

## Features

- Extracts audio from MP4 videos
- Detects piano notes using ML-based transcription
- Maps detected notes to virtual piano key labels
- Outputs formatted sequences with chord brackets `[...]`
- Supports single notes and chords played simultaneously

## Virtual Piano Layout

The tool follows the A-23 Virtual Piano layout where:
- **White keys** (natural notes: C, D, E, F, G, A, B) = unshifted keys (lowercase/numbers)
- **Black keys** (sharp notes: C#, D#, F#, G#, A#) = shifted keys (uppercase or shift+symbol)
- **Left side** (low notes) = number keys 1-7
- **Right side** (high notes) = letter keys (z-m, a-l, q-p, i-p)

### Complete Octave Mapping

**Octave 2 (Lowest) - Number row:**
- C2: `1`, C#2: `!`, D2: `2`, D#2: `@`, E2: `3`, F2: `4`, F#2: `$`, G2: `5`, G#2: `%`, A2: `6`, A#2: `^`, B2: `7`

**Octave 3 - z-m row:**
- C3: `z`, C#3: `Z`, D3: `x`, D#3: `X`, E3: `c`, F3: `v`, F#3: `V`, G3: `b`, G#3: `B`, A3: `n`, A#3: `N`, B3: `m`

**Octave 4 (Middle C) - a-l row:**
- C4: `a`, C#4: `A`, D4: `s`, D#4: `S`, E4: `d`, F4: `f`, F#4: `F`, G4: `g`, G#4: `G`, A4: `h`, A#4: `H`, B4: `j`

**Octave 5 - q-p row:**
- C5: `q`, C#5: `Q`, D5: `w`, D#5: `W`, E5: `e`, F5: `r`, F#5: `R`, G5: `t`, G#5: `T`, A5: `y`, A#5: `Y`, B5: `u`

**Octave 6 (Highest) - i-p row:**
- C6: `i`, C#6: `I`, D6: `o`, D#6: `O`, E6: `p`, F6: `[`, F#6: `{`, G6: `]`

The mapping can be adjusted in `key_mapping.py` if your virtual piano uses a different layout.

## Installation

```bash
pip install -r requirements.txt
```

### Installation Options

- **Full installation** (includes ML-based transcription, more accurate):
  ```bash
  pip install -r requirements.txt
  ```

- **Lightweight installation** (simple transcription only, faster):
  ```bash
  pip install librosa moviepy numpy
  ```

Note: The ML-based transcription requires PyTorch and will download a model checkpoint on first use (approx 100MB).

## Usage

### Web GUI (Recommended)

Start the web server:
```bash
python web_app.py
```

Then open your browser to: **http://localhost:8045**

The web GUI features:
- Drag & drop file upload
- Real-time progress tracking
- Visual display of converted key sequences
- Copy to clipboard functionality
- Download as text file
- Toggle between simple and ML-based transcription

### Command Line Interface

```bash
python main.py input_video.mp4
```

### Options

- `--output, -o`: Output file path (default: output.txt)
- `--time-resolution, -t`: Time resolution in seconds for grouping notes (default: 0.1)
- `--with-timing`: Include timing information in output
- `--groups-per-row`: Number of note groups per row (default: 12)
- `--simple`: Use simple pitch detection (faster but less accurate) instead of ML model

### Examples

Basic usage:
```bash
python main.py tutorial.mp4
```

Custom output file:
```bash
python main.py tutorial.mp4 -o my_keys.txt
```

With timing information:
```bash
python main.py tutorial.mp4 --with-timing
```

Use simple (faster) transcription:
```bash
python main.py tutorial.mp4 --simple
```

## Example Output

```
[qW]       t    [wp]    [ut]   [use]   [usW]  [wutp]   [ysQ]
[sqpi]    [qp]    [f0]    [hW]       z   [xf8]       z [8who]
```

In this output:
- `[qW]` = chord with keys q (unshifted/white) and W (shifted/black) pressed together
- `t` = single note (unshifted/white key)
- `W` = single note (shifted/black key, press Shift+W)
- Spacing indicates timing between note groups

## How It Works

1. Extracts audio from video using moviepy
2. Transcribes piano notes using piano_transcription_inference
3. Converts MIDI notes to virtual piano key labels
4. Groups simultaneous notes into chords
5. Formats output with timing and brackets
