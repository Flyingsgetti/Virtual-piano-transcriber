"""Local web app serving the browser-based visual piano transcriber."""

from flask import Flask, render_template

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


if __name__ == "__main__":
    print("Piano visual transcriber available at http://localhost:8045")
    app.run(host="127.0.0.1", port=8045, debug=False, threaded=True)
