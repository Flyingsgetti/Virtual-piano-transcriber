"""
Format transcribed notes into virtual piano key sequences.
Groups simultaneous notes into chords and formats with brackets.
"""

from typing import List, Tuple
from key_mapping import midi_to_key


class VirtualPianoFormatter:
    """Formats transcribed notes into virtual piano key sequences."""

    def __init__(self, time_resolution: float = 0.1, groups_per_row: int = 12):
        """
        Initialize the formatter.

        Args:
            time_resolution: Time resolution in seconds for grouping notes (default: 0.1s)
            groups_per_row: Number of note groups per row in output (default: 12)
        """
        self.time_resolution = time_resolution
        self.groups_per_row = groups_per_row

    def group_notes_by_time(self, notes: List[Tuple[float, float, int]]) -> List[List[Tuple[float, float, int]]]:
        """
        Group notes that start at approximately the same time.

        Args:
            notes: List of (onset_time, offset_time, midi_note) tuples

        Returns:
            List of note groups, where each group contains notes that start together
        """
        if not notes:
            return []

        # Sort notes by onset time
        sorted_notes = sorted(notes, key=lambda x: x[0])

        groups = []
        current_group = [sorted_notes[0]]
        current_time = sorted_notes[0][0]

        for note in sorted_notes[1:]:
            onset_time = note[0]

            # If this note starts within time_resolution of the current group, add it
            if onset_time - current_time <= self.time_resolution:
                current_group.append(note)
            else:
                # Start a new group
                groups.append(current_group)
                current_group = [note]
                current_time = onset_time

        # Add the last group
        if current_group:
            groups.append(current_group)

        return groups

    def format_group(self, note_group: List[Tuple[float, float, int]]) -> str:
        """
        Format a group of notes into a string representation.

        Args:
            note_group: List of (onset_time, offset_time, midi_note) tuples

        Returns:
            Formatted string (e.g., "[tof]" for chord, "t" for single note)
        """
        if not note_group:
            return ""

        # Map each note to its key label
        keys = []
        for note in note_group:
            midi_note = note[2]
            key = midi_to_key(midi_note)
            if key != '?':
                keys.append(key)

        if not keys:
            return ""

        # Sort keys for consistent output
        keys = sorted(keys)

        # If multiple keys, wrap in brackets (chord)
        if len(keys) > 1:
            return f"[{''.join(keys)}]"
        else:
            return keys[0]

    def format_sequence(self, notes: List[Tuple[float, float, int]]) -> str:
        """
        Format all notes into a complete sequence.

        Args:
            notes: List of (onset_time, offset_time, midi_note) tuples

        Returns:
            Multi-line string with formatted key sequence
        """
        # Group notes by time
        note_groups = self.group_notes_by_time(notes)

        # Format each group
        formatted_groups = [self.format_group(group) for group in note_groups]

        # Determine column width for alignment
        max_width = max(len(group) for group in formatted_groups) if formatted_groups else 8
        column_width = max(max_width + 2, 10)  # Add padding

        # Arrange in rows (like the example output)
        # The example shows multiple rows with time progressing left to right
        groups_per_row = self.groups_per_row

        lines = []
        for i in range(0, len(formatted_groups), groups_per_row):
            row_groups = formatted_groups[i:i + groups_per_row]
            # Right-align each group in its column
            line = ''.join(group.ljust(column_width) for group in row_groups)
            lines.append(line.rstrip())

        return '\n'.join(lines)

    def format_with_timing(self, notes: List[Tuple[float, float, int]]) -> str:
        """
        Format notes with explicit timing information.

        Args:
            notes: List of (onset_time, offset_time, midi_note) tuples

        Returns:
            String with timing information
        """
        groups = self.group_notes_by_time(notes)

        lines = []
        for group in groups:
            if not group:
                continue

            onset_time = group[0][0]
            formatted = self.format_group(group)
            lines.append(f"{onset_time:.3f}s: {formatted}")

        return '\n'.join(lines)
