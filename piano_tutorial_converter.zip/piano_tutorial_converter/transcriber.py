"""
Piano note transcription module.
Extracts audio from video and transcribes piano notes.
"""

import os
import tempfile
from typing import List, Tuple
import numpy as np

try:
    from moviepy import VideoFileClip
except ImportError:
    try:
        from moviepy.editor import VideoFileClip
    except ImportError:
        print("moviepy not installed. Install with: pip install moviepy")
        raise

try:
    from piano_transcription_inference import PianoTranscription
except ImportError:
    print("piano_transcription_inference not installed. Install with: pip install piano_transcription_inference")
    raise


class PianoTranscriber:
    """Transcribes piano notes from video files."""

    def __init__(self):
        """Initialize the transcriber with the piano transcription model."""
        print("Loading piano transcription model...")
        self.transcriber = PianoTranscription(
            device='cpu',  # Use CPU by default, can change to 'cuda' if available
            checkpoint_path=None  # Will download default checkpoint
        )
        print("Model loaded successfully.")

    def extract_audio(self, video_path: str) -> str:
        """
        Extract audio from video file.

        Args:
            video_path: Path to the video file

        Returns:
            Path to the extracted audio file (WAV format)
        """
        print(f"Extracting audio from {video_path}...")

        # Create a temporary file for the audio
        temp_audio = tempfile.NamedTemporaryFile(suffix='.wav', delete=False)
        temp_audio_path = temp_audio.name
        temp_audio.close()

        # Extract audio using moviepy
        video = VideoFileClip(video_path)
        video.audio.write_audiofile(temp_audio_path, logger=None)
        video.close()

        print(f"Audio extracted to {temp_audio_path}")
        return temp_audio_path

    def transcribe(self, audio_path: str) -> List[Tuple[float, float, int]]:
        """
        Transcribe piano notes from audio file.

        Args:
            audio_path: Path to the audio file

        Returns:
            List of tuples (onset_time, offset_time, midi_note)
        """
        print(f"Transcribing piano notes from {audio_path}...")

        # Load audio
        audio, _ = self.transcriber.load_audio(audio_path)

        # Transcribe
        transcribed_dict = self.transcriber.transcribe(
            audio,
            midi_path=None  # Don't save MIDI, we'll process the events directly
        )

        # Extract note events
        note_events = transcribed_dict['est_note_events']
        # note_events format: [[onset_time, offset_time, midi_note, velocity], ...]

        notes = []
        for event in note_events:
            onset_time = event[0]
            offset_time = event[1]
            midi_note = int(event[2])
            notes.append((onset_time, offset_time, midi_note))

        print(f"Detected {len(notes)} notes")
        return notes

    def process_video(self, video_path: str) -> List[Tuple[float, float, int]]:
        """
        Process a video file: extract audio and transcribe notes.

        Args:
            video_path: Path to the video file

        Returns:
            List of tuples (onset_time, offset_time, midi_note)
        """
        # Extract audio
        audio_path = self.extract_audio(video_path)

        try:
            # Transcribe notes
            notes = self.transcribe(audio_path)
            return notes
        finally:
            # Clean up temporary audio file
            if os.path.exists(audio_path):
                os.remove(audio_path)
                print(f"Cleaned up temporary audio file")
