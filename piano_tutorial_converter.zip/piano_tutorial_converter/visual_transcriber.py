"""
Visual piano key detection from video.
Detects lit keys by analyzing video frames.
"""

import cv2
import numpy as np
from typing import List, Tuple
from key_mapping import midi_to_key


class VisualTranscriber:
    """Detects piano key presses from video by tracking lit keys."""

    def __init__(self, key_regions: List[Tuple[int, int, int, int]] = None):
        """
        Initialize with key regions (x, y, width, height) for each piano key.
        If None, will auto-detect from first frame.
        """
        self.key_regions = key_regions  # List of (x, y, w, h) for each key
        self.transpose_offset = 0  # Transpose in semitones

    def detect_key_regions(self, frame: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """
        Auto-detect key regions from a frame.
        Assumes piano keys are arranged horizontally.
        Returns list of (x, y, w, h) for each key.
        """
        # Convert to grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Apply threshold to find key boundaries
        _, thresh = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

        # Find horizontal lines (key boundaries)
        edges = cv2.Canny(thresh, 50, 150)
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=100, minLineLength=100)

        if lines is None:
            # Fallback: divide image into 61 equal regions (61-key piano)
            h, w = frame.shape[:2]
            key_width = w // 61
            regions = [(i * key_width, 0, key_width, h) for i in range(61)]
            return regions

        # Extract x-coordinates of vertical lines
        x_positions = sorted(set([line[0][0] for line in lines]))

        # Create regions between lines
        regions = []
        for i in range(len(x_positions) - 1):
            x = x_positions[i]
            next_x = x_positions[i + 1]
            w = next_x - x
            regions.append((x, 0, w, frame.shape[0]))

        return regions

    def is_key_lit(self, frame: np.ndarray, region: Tuple[int, int, int, int], color_threshold: int = 150) -> bool:
        """
        Check if a key region is lit (brighter than threshold).
        Can be extended to detect specific colors.
        """
        x, y, w, h = region
        roi = frame[y:y+h, x:x+w]

        # Convert to grayscale
        gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

        # Check if average brightness exceeds threshold
        avg_brightness = np.mean(gray)
        return avg_brightness > color_threshold

    def detect_lit_keys_by_color(self, frame: np.ndarray, region: Tuple[int, int, int, int], color: Tuple[int, int, int] = None) -> bool:
        """
        Check if a key region is lit with a specific color (B, G, R).
        If color is None, checks for any bright light.
        """
        x, y, w, h = region
        roi = frame[y:y+h, x:x+w]

        if color is None:
            # Any bright light
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
            return np.mean(gray) > 150

        # Check for specific color
        b, g, r = color
        mask = cv2.inRange(roi, (b-30, g-30, r-30), (b+30, g+30, r+30))
        return np.count_nonzero(mask) > (w * h * 0.3)  # At least 30% of region

    def process_video(self, video_path: str) -> List[Tuple[float, List[int]]]:
        """
        Process video and detect key presses.

        Args:
            video_path: Path to video file

        Returns:
            List of (timestamp, [key_indices]) tuples
        """
        cap = cv2.VideoCapture(video_path)
        fps = cap.get(cv2.CAP_PROP_FPS)

        # Read first frame to detect key regions
        ret, first_frame = cap.read()
        if not ret:
            return []

        if self.key_regions is None:
            self.key_regions = self.detect_key_regions(first_frame)

        key_presses = []
        prev_lit_keys = set()
        frame_count = 0

        while True:
            ret, frame = cap.read()
            if not ret:
                break

            timestamp = frame_count / fps
            lit_keys = []

            # Detect which keys are lit
            for i, region in enumerate(self.key_regions):
                if self.is_key_lit(frame, region):
                    lit_keys.append(i)

            lit_keys_set = set(lit_keys)

            # New key press detected
            if lit_keys_set != prev_lit_keys and lit_keys:
                key_presses.append((timestamp, lit_keys))
                prev_lit_keys = lit_keys_set

            frame_count += 1

        cap.release()
        return key_presses

    def set_transpose(self, semitones: int):
        """Set transpose offset in semitones."""
        self.transpose_offset = semitones
